

<?php $__env->startSection('title', 'Galeri Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Galeri Produk</h2>
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <!-- Menampilkan gambar produk -->
                        <img src="<?php echo e(asset('storage/'.$product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_users', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\uts_webpro\website_toko_baju\resources\views\user\gallery.blade.php ENDPATH**/ ?>