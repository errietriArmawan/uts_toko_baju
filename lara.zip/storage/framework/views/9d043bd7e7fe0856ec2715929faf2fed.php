

<?php $__env->startSection('title', 'Profil Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card shadow-sm border-0">
                <div class="card-header bg-white">
                    <h4 class="mb-0">Profil Saya</h4>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <strong>Nama:</strong>
                        <p class="text-muted"><?php echo e($user->name); ?></p>
                    </div>

                    <div class="mb-3">
                        <strong>Email:</strong>
                        <p class="text-muted"><?php echo e($user->email); ?></p>
                    </div>

                    <a href="<?php echo e(route('user.profile.edit')); ?>" class="btn btn-outline-primary">Edit Profil</a>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_users', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\uts_webpro\website_toko_baju\resources\views\user\profile.blade.php ENDPATH**/ ?>