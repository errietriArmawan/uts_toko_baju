

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h2 class="mb-4">Daftar Produk</h2>

    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary mb-3">Tambah Produk</a>

    
    <form action="<?php echo e(route('admin.products')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Cari nama produk..." value="<?php echo e(request('search')); ?>">
            <button class="btn btn-outline-secondary" type="submit">Cari</button>
        </div>
    </form>

    
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Gambar</th>
                    <th>Nama</th>
                    <th>Link</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($product->image): ?>
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover;">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/60" alt="No Image" class="img-thumbnail" style="width: 60px; height: 60px;">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($product->name); ?></td>
                    <td>
                        <?php if($product->link): ?>
                            <a href="<?php echo e($product->link); ?>" target="_blank" class="btn btn-sm btn-outline-primary">Lihat</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.products.show', $product->id)); ?>" class="btn btn-sm btn-info me-2">Detail</a>
                        <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-sm btn-warning me-2">Edit</a>
                        <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Yakin ingin hapus?')" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Tidak ada produk ditemukan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\uts_webpro\website_toko_baju\resources\views\admin\product.blade.php ENDPATH**/ ?>