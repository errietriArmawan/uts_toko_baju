<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'User Panel'); ?></title>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1;
        }
    </style>
</head>
<body>

    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">User Panel</a>

            <div class="d-flex w-100 justify-content-between">
                <ul class="navbar-nav flex-row">
                    <li class="nav-item me-3">
                        <a class="nav-link" href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a>
                    </li>
                    <li class="nav-item me-3">
                        <a class="nav-link" href="<?php echo e(route('user.profile')); ?>">Profil</a>
                    </li>
                    <li class="nav-item me-3">
                        <a class="nav-link" href="<?php echo e(route('user.products')); ?>">Produk</a>
                    </li>
                    <li class="nav-item me-3">
                        <a class="nav-link" href="<?php echo e(route('user.gallery')); ?>">Galeri</a>
                    </li>
                    <li class="nav-item me-3">
                        <a class="nav-link" href="<?php echo e(route('user.contact')); ?>">Kontak</a>
                    </li>
                </ul>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light btn-sm">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    
    <main class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer class="bg-light py-3 text-center mt-auto">
        <div class="container">
            <small>&copy; <?php echo e(date('Y')); ?> User Panel - All rights reserved.</small>
        </div>
    </footer>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH D:\uts_webpro\website_toko_baju\resources\views\layouts\app_users.blade.php ENDPATH**/ ?>