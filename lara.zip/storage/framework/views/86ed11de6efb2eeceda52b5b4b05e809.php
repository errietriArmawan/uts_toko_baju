

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-warning text-white">
                    <h4 class="mb-0">Edit Produk</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Nama Produk -->
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($product->name); ?>" required placeholder="Masukkan nama produk">
                        </div>

                        <!-- Deskripsi Produk -->
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi Produk</label>
                            <textarea class="form-control" id="description" name="description" rows="4" required placeholder="Tulis deskripsi produk"><?php echo e($product->description); ?></textarea>
                        </div>

                        <!-- Link Produk -->
                        <div class="mb-3">
                            <label for="link" class="form-label">Link Produk</label>
                            <input type="url" class="form-control" id="link" name="link" value="<?php echo e($product->link); ?>" placeholder="Masukkan URL produk jika ada">
                        </div>

                        <!-- Gambar Produk -->
                        <div class="mb-3">
                            <label for="image" class="form-label">Gambar Produk</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            <?php if($product->image): ?>
                                <div class="mt-3">
                                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-thumbnail" width="150" alt="Gambar Produk">
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-warning w-100">Update Produk</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\uts_webpro\website_toko_baju\resources\views\admin\edit.blade.php ENDPATH**/ ?>