

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h2 class="mb-4">Detail Produk</h2>

    
    <div class="card mb-4 shadow-sm">
        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>" style="height: 250px; object-fit: contain;">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($product->name); ?></h5>
            <p class="card-text"><?php echo e($product->description); ?></p>
            
            <?php if($product->link): ?>
                <a href="<?php echo e($product->link); ?>" class="btn btn-outline-info" target="_blank">
                    <i class="bi bi-box-arrow-up-right"></i> Lihat Produk
                </a>
            <?php else: ?>
                <span class="text-muted">Link produk tidak tersedia</span>
            <?php endif; ?>
        </div>
    </div>

    
    <a href="<?php echo e(route('admin.products')); ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left-circle"></i> Kembali ke Daftar Produk
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\uts_webpro\website_toko_baju\resources\views\admin\show.blade.php ENDPATH**/ ?>