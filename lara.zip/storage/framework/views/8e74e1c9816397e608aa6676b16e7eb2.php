

<?php $__env->startSection('title', 'Detail Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row align-items-center">
        <div class="col-md-6 mb-4 mb-md-0">
            <div class="border rounded shadow-sm p-3">
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid w-100 rounded">
            </div>
        </div>
        <div class="col-md-6">
            <h2 class="mb-3"><?php echo e($product->name); ?></h2>
            <p class="text-muted"><?php echo e($product->description); ?></p>

            <?php if($product->link): ?>
                <a href="<?php echo e($product->link); ?>" target="_blank" class="btn btn-outline-primary mt-3">
                    🔗 Kunjungi Toko Online
                </a>
            <?php else: ?>
                <div class="alert alert-secondary mt-3">
                    Tautan toko online belum tersedia.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_users', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\uts_webpro\website_toko_baju\resources\views\user\product-detail.blade.php ENDPATH**/ ?>